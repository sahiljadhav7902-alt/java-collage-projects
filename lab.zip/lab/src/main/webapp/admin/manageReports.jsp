<%-- 
    Document   : manageReports
    Created on : 18-Feb-2026, 5:43:00 pm
    Author     : sahil jadhav
--%>

<%@ page import="com.mycompany.lab.BllReportGenerator" %>
<%@ page import="java.text.DecimalFormat" %>

<%
    // LOGIC PRESERVED
    BllReportGenerator bll = new BllReportGenerator();
    BllReportGenerator.DashboardStats stats = bll.getDashboardStats();
    DecimalFormat df = new DecimalFormat("$#,###.00");
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics | Lab Portal</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-blue: #0561FC;
            --slate-bg: #f8fafc;
            --dark-header: #1e293b;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--slate-bg);
            color: #334155;
        }

        .page-header {
            background: white;
            border-bottom: 1px solid #e2e8f0;
            padding: 30px 0;
            margin-bottom: 25px;
        }

        /* Analytics Card Styling */
        .stats-card {
            background: white;
            border-radius: 16px;
            border: 1px solid rgba(0,0,0,0.05);
            padding: 1.5rem;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            height: 100%;
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.05);
        }

        .icon-box {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        }

        .stats-label {
            font-size: 0.85rem;
            font-weight: 500;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stats-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--dark-header);
            margin: 0.25rem 0;
        }

        /* Export Card Styling */
        .content-card {
            background: white;
            border-radius: 16px;
            border: 1px solid rgba(0,0,0,0.05);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
            overflow: hidden;
            padding: 2rem;
        }

        .export-btn {
            border: 1px solid #e2e8f0;
            background: #fff;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            transition: all 0.2s;
            text-decoration: none;
            color: var(--dark-header);
            display: block;
        }

        .export-btn:hover {
            background: #f8fafc;
            border-color: var(--primary-blue);
            color: var(--primary-blue);
        }

        .export-btn i {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
            display: block;
        }
    </style>
</head>

<body>
    <jsp:include page="./adminNavbar.jsp" />

    <header class="page-header">
        <div class="container-fluid px-5">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="fw-bold m-0">Reports & Analytics</h2>
                    <p class="text-muted small mb-0">Operational intelligence and data export center</p>
                </div>
                <div>
                    <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
                        <i class="bi bi-printer me-1"></i> Print Summary
                    </button>
                </div>
            </div>
        </div>
    </header>

    <div class="container-fluid px-5 pb-5">
        
        <div class="row g-4 mb-5">
            <div class="col-md-3">
                <div class="stats-card">
                    <div class="icon-box bg-primary-subtle text-primary">
                        <i class="bi bi-people-fill fs-4"></i>
                    </div>
                    <div class="stats-label">Total Patients</div>
                    <div class="stats-value"><%= stats.totalPatients %></div>
                    <div class="text-success small fw-medium">Active database</div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stats-card">
                    <div class="icon-box bg-warning-subtle text-warning">
                        <i class="bi bi-clipboard-data fs-4"></i>
                    </div>
                    <div class="stats-label">Pending Orders</div>
                    <div class="stats-value text-warning"><%= stats.pendingOrders %></div>
                    <div class="text-muted small">Out of <%= stats.totalOrders %> total</div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stats-card">
                    <div class="icon-box bg-success-subtle text-success">
                        <i class="bi bi-currency-dollar fs-4"></i>
                    </div>
                    <div class="stats-label">Total Revenue</div>
                    <div class="stats-value text-success"><%= df.format(stats.totalRevenue) %></div>
                    <div class="text-muted small">Cleared payments</div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stats-card">
                    <div class="icon-box bg-danger-subtle text-danger">
                        <i class="bi bi-box-seam fs-4"></i>
                    </div>
                    <div class="stats-label">Low Stock Items</div>
                    <div class="stats-value text-danger"><%= stats.lowStockItems %></div>
                    <div class="text-danger small fw-medium">Action required</div>
                </div>
            </div>
        </div>

        <div class="content-card">
            <div class="mb-4">
                <h5 class="fw-bold mb-1">Data Export center</h5>
                <p class="text-muted small">Generate standardized CSV reports for external analysis in Excel</p>
            </div>
            
            <div class="row g-4">
                <div class="col-md-3">
                    <a href="exportData.jsp?type=patients" class="export-btn">
                        <i class="bi bi-person-down text-primary"></i>
                        <span class="fw-semibold">Patient Master</span>
                        <div class="text-muted extra-small" style="font-size: 0.7rem;">Demographics & History</div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="exportData.jsp?type=orders" class="export-btn">
                        <i class="bi bi-cart-check text-primary"></i>
                        <span class="fw-semibold">Order History</span>
                        <div class="text-muted extra-small" style="font-size: 0.7rem;">Test requests & Status</div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="exportData.jsp?type=billing" class="export-btn">
                        <i class="bi bi-cash-stack text-success"></i>
                        <span class="fw-semibold">Financial Report</span>
                        <div class="text-muted extra-small" style="font-size: 0.7rem;">Invoices & Payments</div>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="exportData.jsp?type=inventory" class="export-btn">
                        <i class="bi bi-boxes text-warning"></i>
                        <span class="fw-semibold">Inventory Audit</span>
                        <div class="text-muted extra-small" style="font-size: 0.7rem;">Stock Levels & Expiry</div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>